$(document).ready(function() {

	$('.show-log').click(function(event) {
		event.preventDefault();
		$('.log').slideToggle();
	});

});